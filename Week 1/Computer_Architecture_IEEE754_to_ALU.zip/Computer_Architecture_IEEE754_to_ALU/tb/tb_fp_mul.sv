`timescale 1ns/1ps

module tb_fp_mul;

    logic [63:0] a;
    logic [63:0] b;
    logic [63:0] result;

    fp_mul #(.WIDTH(64)) dut (
        .a(a),
        .b(b),
        .result(result)
    );

    task automatic test_mul(
        input [63:0] in_a,
        input [63:0] in_b,
        input [63:0] expected
    );
        begin
            a = in_a;
            b = in_b;

            #1;

            $display("---------------------------------------------");
            $display("A        = %h",a);
            $display("B        = %h",b);
            $display("Result   = %h",result);
            $display("Expected = %h",expected);

            if (result === expected)
                $display("STATUS   = PASS");
            else
                $display("STATUS   = FAIL");
        end
    endtask

    initial begin
        $display("=============================================");
        $display("IEEE-754 FP64 MULTIPLICATION TEST");
        $display("=============================================");

        // Basic multiplication

        test_mul(
            64'h3FF0000000000000,
            64'h4000000000000000,
            64'h4000000000000000
        );

        test_mul(
            64'h3FF8000000000000,
            64'h4000000000000000,
            64'h4008000000000000
        );

        test_mul(
            64'h4004000000000000,
            64'h4010000000000000,
            64'h4024000000000000
        );

        test_mul(
            64'h3FE0000000000000,
            64'h3FE0000000000000,
            64'h3FD0000000000000
        );

        // Negative numbers

        test_mul(
            64'hC000000000000000,
            64'h4008000000000000,
            64'hC018000000000000
        );

        test_mul(
            64'hC000000000000000,
            64'hC008000000000000,
            64'h4018000000000000
        );

        // Zero

        test_mul(
            64'h0000000000000000,
            64'h4000000000000000,
            64'h0000000000000000
        );

        test_mul(
            64'h8000000000000000,
            64'h4008000000000000,
            64'h8000000000000000
        );

        // Infinity

        test_mul(
            64'h7FF0000000000000,
            64'h4000000000000000,
            64'h7FF0000000000000
        );

        test_mul(
            64'hFFF0000000000000,
            64'h4000000000000000,
            64'hFFF0000000000000
        );

        test_mul(
            64'h7FF0000000000000,
            64'h0000000000000000,
            64'h7FF8000000000001
        );

        // Overflow

        test_mul(
            64'h7FEFFFFFFFFFFFFF,
            64'h4000000000000000,
            64'h7FF0000000000000
        );

        // Underflow

        test_mul(
            64'h0010000000000000,
            64'h3FE0000000000000,
            64'h0008000000000000
        );

        // NaN

        test_mul(
            64'h7FF8000000000001,
            64'h3FF0000000000000,
            64'h7FF8000000000001
        );

        $display("=============================================");
        $display("MULTIPLICATION TESTS COMPLETED");
        $display("=============================================");

        $finish;
    end

endmodule