`timescale 1ns/1ps

module tb_fp_alu32;

    logic [31:0] a;
    logic [31:0] b;
    logic [1:0] op;
    logic [31:0] result;

    localparam logic [1:0] ADD = 2'b00;
    localparam logic [1:0] SUB = 2'b01;
    localparam logic [1:0] MUL = 2'b10;
    localparam logic [1:0] DIV = 2'b11;

    fp_alu #(.WIDTH(32)) dut (
        .a(a),
        .b(b),
        .op(op),
        .result(result)
    );

    task automatic test(
        input [31:0] x,
        input [31:0] y,
        input [1:0] operation,
        input [31:0] expected
    );
        begin
            a = x;
            b = y;
            op = operation;

            #1;

            if (result === expected)
                $display(
                    "PASS: A=%h B=%h OP=%b RESULT=%h",
                    a,b,op,result
                );
            else
                $display(
                    "FAIL: A=%h B=%h OP=%b RESULT=%h EXPECTED=%h",
                    a,b,op,result,expected
                );
        end
    endtask

    initial begin
        $display("");
        $display("=============================================");
        $display("FP32 ALU TEST");
        $display("=============================================");

        // ADD

        test(
            32'h3F800000,
            32'h40000000,
            ADD,
            32'h40400000
        );

        test(
            32'h40A00000,
            32'h40400000,
            ADD,
            32'h41000000
        );

        test(
            32'hC0000000,
            32'h40A00000,
            ADD,
            32'h40400000
        );

        // SUB

        test(
            32'h40A00000,
            32'h40000000,
            SUB,
            32'h40400000
        );

        test(
            32'h40000000,
            32'h40A00000,
            SUB,
            32'hC0400000
        );

        // MUL

        test(
            32'h40000000,
            32'h40400000,
            MUL,
            32'h40C00000
        );

        test(
            32'hC0000000,
            32'h40400000,
            MUL,
            32'hC0C00000
        );

        // DIV

        test(
            32'h40C00000,
            32'h40000000,
            DIV,
            32'h40400000
        );

        test(
            32'h3F800000,
            32'h40000000,
            DIV,
            32'h3F000000
        );

        // Special values

        test(
            32'h3F800000,
            32'h00000000,
            DIV,
            32'h7F800000
        );

        test(
            32'h7F800000,
            32'h00000000,
            MUL,
            32'h7FC00001
        );

        $display("=============================================");
        $display("FP32 TEST COMPLETED");
        $display("=============================================");

        $finish;
    end

endmodule