`timescale 1ns/1ps

module tb_fp_alu_corner;

    logic [63:0] a;
    logic [63:0] b;
    logic [1:0] op;
    logic [63:0] result;

    integer total;
    integer passed;
    integer failed;

    localparam logic [1:0] ADD = 2'b00;
    localparam logic [1:0] SUB = 2'b01;
    localparam logic [1:0] MUL = 2'b10;
    localparam logic [1:0] DIV = 2'b11;

    // DUT

    fp_alu #(.WIDTH(64)) dut (
        .a(a),
        .b(b),
        .op(op),
        .result(result)
    );

    // Test task

    task automatic test(
        input [63:0] x,
        input [63:0] y,
        input [1:0] operation,
        input [63:0] expected,
        input [200*8:1] name
    );
        begin
            a = x;
            b = y;
            op = operation;

            #1;

            total = total+1;

            if (result === expected) begin
                passed = passed+1;
                $display("PASS: %s",name);
            end
            else begin
                failed = failed+1;

                $display("");
                $display("FAIL: %s",name);
                $display("A        = %h",a);
                $display("B        = %h",b);
                $display("OP       = %b",op);
                $display("RESULT   = %h",result);
                $display("EXPECTED = %h",expected);
                $display("");
            end
        end
    endtask

    // Tests

    initial begin
        total = 0;
        passed = 0;
        failed = 0;

        $display("");
        $display("=============================================");
        $display("IEEE-754 FP64 CORNER CASE TEST");
        $display("=============================================");

        // Addition

        test(
            64'h3FF0000000000000,
            64'h3FF0000000000000,
            ADD,
            64'h4000000000000000,
            "1 + 1 = 2"
        );

        test(
            64'h3FF0000000000000,
            64'hBFF0000000000000,
            ADD,
            64'h0000000000000000,
            "1 + (-1) = +0"
        );

        test(
            64'hBFF0000000000000,
            64'hBFF0000000000000,
            ADD,
            64'hC000000000000000,
            "-1 + (-1) = -2"
        );

        test(
            64'h0000000000000000,
            64'h0000000000000000,
            ADD,
            64'h0000000000000000,
            "+0 + +0 = +0"
        );

        test(
            64'h0000000000000000,
            64'h8000000000000000,
            ADD,
            64'h0000000000000000,
            "+0 + -0"
        );

        test(
            64'h7FF0000000000000,
            64'h7FF0000000000000,
            ADD,
            64'h7FF0000000000000,
            "Inf + Inf = Inf"
        );

        test(
            64'h7FF0000000000000,
            64'hFFF0000000000000,
            ADD,
            64'h7FF8000000000001,
            "Inf + (-Inf) = NaN"
        );

        test(
            64'h7FF8000000000001,
            64'h3FF0000000000000,
            ADD,
            64'h7FF8000000000001,
            "NaN + 1 = NaN"
        );

        // Subtraction

        test(
            64'h3FF0000000000000,
            64'h3FF0000000000000,
            SUB,
            64'h0000000000000000,
            "1 - 1 = 0"
        );

        test(
            64'h3FF0000000000000,
            64'hBFF0000000000000,
            SUB,
            64'h4000000000000000,
            "1 - (-1) = 2"
        );

        test(
            64'hBFF0000000000000,
            64'h3FF0000000000000,
            SUB,
            64'hC000000000000000,
            "-1 - 1 = -2"
        );

        test(
            64'h7FF0000000000000,
            64'h7FF0000000000000,
            SUB,
            64'h7FF8000000000001,
            "Inf - Inf = NaN"
        );

        // Multiplication

        test(
            64'h0000000000000000,
            64'h4000000000000000,
            MUL,
            64'h0000000000000000,
            "0 × 2 = 0"
        );

        test(
            64'h8000000000000000,
            64'h4000000000000000,
            MUL,
            64'h8000000000000000,
            "-0 × 2 = -0"
        );

        test(
            64'h7FF0000000000000,
            64'h0000000000000000,
            MUL,
            64'h7FF8000000000001,
            "Inf × 0 = NaN"
        );

        test(
            64'h7FF0000000000000,
            64'h7FF0000000000000,
            MUL,
            64'h7FF0000000000000,
            "Inf × Inf = Inf"
        );

        test(
            64'hC000000000000000,
            64'h4008000000000000,
            MUL,
            64'hC018000000000000,
            "-2 × 3 = -6"
        );

        // Division

        test(
            64'h0000000000000000,
            64'h4000000000000000,
            DIV,
            64'h0000000000000000,
            "0 / 2 = 0"
        );

        test(
            64'h8000000000000000,
            64'h4000000000000000,
            DIV,
            64'h8000000000000000,
            "-0 / 2 = -0"
        );

        test(
            64'h0000000000000000,
            64'h0000000000000000,
            DIV,
            64'h7FF8000000000001,
            "0 / 0 = NaN"
        );

        test(
            64'h3FF0000000000000,
            64'h0000000000000000,
            DIV,
            64'h7FF0000000000000,
            "1 / 0 = Inf"
        );

        test(
            64'hBFF0000000000000,
            64'h0000000000000000,
            DIV,
            64'hFFF0000000000000,
            "-1 / 0 = -Inf"
        );

        test(
            64'h7FF0000000000000,
            64'h7FF0000000000000,
            DIV,
            64'h7FF8000000000001,
            "Inf / Inf = NaN"
        );

        test(
            64'h7FF0000000000000,
            64'h4000000000000000,
            DIV,
            64'h7FF0000000000000,
            "Inf / 2 = Inf"
        );

        test(
            64'h4000000000000000,
            64'h7FF0000000000000,
            DIV,
            64'h0000000000000000,
            "2 / Inf = 0"
        );

        // Subnormal / boundary cases

        // Smallest positive subnormal

        test(
            64'h0000000000000001,
            64'h3FF0000000000000,
            MUL,
            64'h0000000000000001,
            "MIN_SUBNORMAL × 1"
        );

        // Smallest normal × 0.5

        test(
            64'h0010000000000000,
            64'h3FE0000000000000,
            MUL,
            64'h0008000000000000,
            "MIN_NORMAL × 0.5"
        );

        // Summary

        $display("");
        $display("=============================================");
        $display("CORNER TEST SUMMARY");
        $display("=============================================");

        $display("TOTAL  = %0d",total);
        $display("PASSED = %0d",passed);
        $display("FAILED = %0d",failed);

        if (failed == 0)
            $display("STATUS = ALL TESTS PASSED");
        else
            $display("STATUS = FAILURES DETECTED");

        $display("=============================================");

        $finish;
    end

endmodule